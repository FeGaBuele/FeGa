/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neptuno;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author FeGa
 */
public class FrmFactura extends javax.swing.JInternalFrame {
    Font fuente = new Font("Dialog", Font.PLAIN, 10);
    PrintJob pj; // abre el cuadro de dialogo de impresion
    Graphics pagina;
    /*static*/ int inc = 120;
    
    String clidireccion;
    String clitelef;
    String idCliente;
    
   
    double subto1;
    double subto2;
    double subto3;
    double subto4;
    double descto;
    double iva;
    double total;
    
    public void imprimir(String nombre, String fecha, String direccion, String telefono, String codigo1, String codigo2,
            String codigo3, String codigo4, String descripcion1, String descripcion2,String descripcion3, String descripcion4,
            String cantidad1, String cantidad2,String cantidad3, String cantidad4,
            String precio1, String precio2,String precio3, String precio4,
            String subtotal1, String subtotal2,String subtotal3, String subtotal4, 
            String subtotal, String descuento, String iva, String total )
    {
        try
        {
            pagina = pj.getGraphics();
            pagina.setFont(fuente);
            pagina.setColor(Color.black);
            //pagina.drawString(titulo, 200,100);
            pagina.drawString(nombre, 100, inc);
            pagina.drawString(fecha, 250, inc);
            pagina.drawString(direccion, 100, inc+20);
            pagina.drawString(telefono, 250, inc+20);
            pagina.drawString(codigo1, 50, inc+60);
            pagina.drawString(codigo2, 50, inc+80);
            pagina.drawString(codigo3, 50, inc+100);
            pagina.drawString(codigo4, 50, inc+120);
            pagina.drawString(descripcion1, 100, inc+60);
            pagina.drawString(descripcion2, 100, inc+80);
            pagina.drawString(descripcion3, 100, inc+100);
            pagina.drawString(descripcion4, 100, inc+120);
            pagina.drawString(cantidad1, 180, inc+60);
            pagina.drawString(cantidad2, 180, inc+80);
            pagina.drawString(cantidad3, 180, inc+100);
            pagina.drawString(cantidad4, 180, inc+120);
            pagina.drawString(precio1, 220, inc+60);
            pagina.drawString(precio2, 220, inc+80);
            pagina.drawString(precio3, 220, inc+100);
            pagina.drawString(precio4, 220, inc+120);
            pagina.drawString(subtotal1, 250, inc+60);
            pagina.drawString(subtotal2, 250, inc+80);
            pagina.drawString(subtotal3, 250, inc+100);
            pagina.drawString(subtotal4, 250, inc+120);
            
            pagina.drawString(subtotal, 250, inc+150);
            pagina.drawString(descuento, 250, inc+170);
            pagina.drawString(iva, 250, inc+190);
            pagina.drawString(total, 250, inc+210);
            //pagina.drawString(edad, 150, inc+=30);
            //pagina.drawString(domicilio, 150, inc+=30);
            //pagina.drawString(telefono, 150, inc+=30);
            //pagina.drawString(mail, 150, inc+=30);
            pagina.dispose();
            pj.end();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Impresión cancelada...", "Aviso",JOptionPane.WARNING_MESSAGE);
        }
    }


    
    /**
     * Creates new form FrmFactura
     */
    public FrmFactura() {
        initComponents();

        
        JButton[] botones = {btnNuevo,btnGuardar,btnModificar,btnEliminar,btnImprimir};
        int separacion =50;
        for (JButton btn : botones) // recorrer cada boton
        {
            btn.setBounds(separacion,20,35,35); // btn va a instanciar cda variable botones
            separacion+=60;
        }
        
        JLabel[] labelsup1 = {lbl1,lblfactu};
        int seplblsup = 160;
        for(JLabel lb : labelsup1)
        {
            lb.setBounds(seplblsup, 80, 60, 23);
            seplblsup+=80;
        }
        
        JLabel[] labelsupder = {lbl3,lbl4};
        int seplblder = 120;
        for (JLabel lb2 : labelsupder)
        {
            lb2.setBounds(20, seplblder, 60, 23);
            seplblder+=35;
        }
        
        cbxCliente.setBounds(105, 120, 100, 23);
        txtDireccion.setBounds(105, 155, 100, 23);
        txtDireccion.setText("");
        
        JLabel[] labelsupizq = {lbl5,lbl6};
        int seplblizq = 120;
        for (JLabel lb3 : labelsupizq)
        {
            lb3.setBounds(250, seplblizq, 60, 23);
            seplblizq+=35;
        }
        
        JTextField[] txtfech = {txtFecha, txtTelefono};
        int sepfech=120;
        for (JTextField txtft : txtfech )
        {
            txtft.setBounds(320, sepfech, 100, 23);
            sepfech+=35;
            txtft.setText("");
        }
        
        JLabel[] labelmedio = {lbl7,lbl8,lbl9,lbl10,lbl11};
        int sepmedio = 20;
        for (JLabel lb4 : labelmedio)
        {
            lb4.setBounds(sepmedio, 215, 70, 23);
            sepmedio+=80;
        }
        
        JTextField[] txtFieldsDescrip = {txtDescripcion1, txtDescripcion2, txtDescripcion3, txtDescripcion4};
        int separaciondescrip=245;
        for (JTextField txtdesc : txtFieldsDescrip )
        {
            txtdesc.setBounds(100, separaciondescrip, 70, 23);
            separaciondescrip+=28;
            txtdesc.setText("");
        }
        
        JTextField[] txtcantidad = {txtCantidad1,txtCantidad2,txtCantidad3,txtCantidad4};
        int sepcantidad = 245;
        for(JTextField txtcant : txtcantidad)
        {
            txtcant.setBounds(180, sepcantidad, 70, 23);
            sepcantidad+=28;
            txtcant.setText("");
        }
        
        JTextField[] txtprecio = {txtPrecio1,txtPrecio2,txtPrecio3,txtPrecio4};
        int sepprecio = 245;
        for(JTextField txtprec : txtprecio)
        {
            txtprec.setBounds(260, sepprecio, 70, 23);
            sepprecio+=28;
            txtprec.setText("");
        }
        
        JTextField[] txtsubtotal = {txtSubtotal1,txtSubtotal2,txtSubtotal3,txtSubtotal4};
        int sepsubto = 245;
        for(JTextField txtsubto : txtsubtotal)
        {
            txtsubto.setBounds(340, sepsubto, 70, 23);
            sepsubto+=28;
            txtsubto.setText("");
        }
        
        JComboBox[] cbxcodigo = {cbxCodigo1,cbxCodigo2,cbxCodigo3,cbxCodigo4};
        int sepcodigo = 245;
        for(JComboBox cbxcod : cbxcodigo)
        {
            cbxcod.setBounds(20, sepcodigo, 70, 23);
            sepcodigo+=28;
        }  
        
        JLabel[] lblfinales={lbl12,lbl13,lbl14,lbl15};
        int seplblfinales = 390;
        for(JLabel lblfin : lblfinales)
        {
            lblfin.setBounds(180, seplblfinales, 80, 23);
            seplblfinales+=30;
        }
        
        JTextField[] txtfinales = {txtSubtotal,txtDescuento,txtIva,txtTotal};
        int septxtfin = 390;
        for (JTextField txtfin : txtfinales)
        {
            txtfin.setBounds(300, septxtfin, 60, 23);
            septxtfin+=30;
            txtfin.setText("");
        }
        
        JTextField[] txtfinales2 = {txtPorcentajeDsct,txtPorcentajeIva};
        int septxtfin2 = 420;
        for (JTextField txtfin2 : txtfinales2)
        {
            txtfin2.setBounds(250, septxtfin2, 30, 23);
            septxtfin2+=30;
            txtfin2.setText("");
        }
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        txtFecha.setText(dateFormat.format(date));
        
        
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnImprimir = new javax.swing.JButton();
        txtDireccion = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        lbl1 = new javax.swing.JLabel();
        lblfactu = new javax.swing.JLabel();
        lbl3 = new javax.swing.JLabel();
        lbl4 = new javax.swing.JLabel();
        lbl5 = new javax.swing.JLabel();
        lbl6 = new javax.swing.JLabel();
        lbl7 = new javax.swing.JLabel();
        cbxCodigo1 = new javax.swing.JComboBox<>();
        txtDescripcion1 = new javax.swing.JTextField();
        txtCantidad1 = new javax.swing.JTextField();
        txtPrecio1 = new javax.swing.JTextField();
        txtSubtotal1 = new javax.swing.JTextField();
        lbl8 = new javax.swing.JLabel();
        lbl9 = new javax.swing.JLabel();
        lbl10 = new javax.swing.JLabel();
        lbl11 = new javax.swing.JLabel();
        cbxCodigo2 = new javax.swing.JComboBox<>();
        txtDescripcion2 = new javax.swing.JTextField();
        txtCantidad2 = new javax.swing.JTextField();
        txtPrecio2 = new javax.swing.JTextField();
        txtSubtotal2 = new javax.swing.JTextField();
        cbxCodigo3 = new javax.swing.JComboBox<>();
        txtDescripcion3 = new javax.swing.JTextField();
        txtCantidad3 = new javax.swing.JTextField();
        txtPrecio3 = new javax.swing.JTextField();
        txtSubtotal3 = new javax.swing.JTextField();
        cbxCodigo4 = new javax.swing.JComboBox<>();
        txtDescripcion4 = new javax.swing.JTextField();
        txtCantidad4 = new javax.swing.JTextField();
        txtPrecio4 = new javax.swing.JTextField();
        txtSubtotal4 = new javax.swing.JTextField();
        lbl12 = new javax.swing.JLabel();
        lbl13 = new javax.swing.JLabel();
        lbl14 = new javax.swing.JLabel();
        lbl15 = new javax.swing.JLabel();
        txtSubtotal = new javax.swing.JTextField();
        txtDescuento = new javax.swing.JTextField();
        cbxCliente = new javax.swing.JComboBox<>();
        txtIva = new javax.swing.JTextField();
        txtTotal = new javax.swing.JTextField();
        txtPorcentajeDsct = new javax.swing.JTextField();
        txtPorcentajeIva = new javax.swing.JTextField();

        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(450, 600));
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/nuevo.png"))); // NOI18N
        btnNuevo.setPreferredSize(new java.awt.Dimension(30, 30));
        getContentPane().add(btnNuevo);
        btnNuevo.setBounds(21, 21, 41, 37);

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/guardar.png"))); // NOI18N
        btnGuardar.setPreferredSize(new java.awt.Dimension(30, 30));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(90, 21, 39, 37);

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/modificar.png"))); // NOI18N
        btnModificar.setPreferredSize(new java.awt.Dimension(30, 30));
        getContentPane().add(btnModificar);
        btnModificar.setBounds(160, 20, 39, 37);

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/eliminar.png"))); // NOI18N
        btnEliminar.setPreferredSize(new java.awt.Dimension(30, 30));
        getContentPane().add(btnEliminar);
        btnEliminar.setBounds(230, 20, 39, 37);

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/imprimir.png"))); // NOI18N
        btnImprimir.setPreferredSize(new java.awt.Dimension(30, 30));
        btnImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirActionPerformed(evt);
            }
        });
        getContentPane().add(btnImprimir);
        btnImprimir.setBounds(300, 20, 41, 37);

        txtDireccion.setText("jTextField2");
        getContentPane().add(txtDireccion);
        txtDireccion.setBounds(105, 162, 55, 19);

        txtFecha.setText("jTextField3");
        getContentPane().add(txtFecha);
        txtFecha.setBounds(343, 122, 55, 19);

        txtTelefono.setText("jTextField4");
        getContentPane().add(txtTelefono);
        txtTelefono.setBounds(340, 162, 55, 19);

        lbl1.setText("Factura");
        getContentPane().add(lbl1);
        lbl1.setBounds(107, 76, 37, 15);

        lblfactu.setText("XXXX");
        getContentPane().add(lblfactu);
        lblfactu.setBounds(198, 76, 28, 15);

        lbl3.setText("Cliente:");
        getContentPane().add(lbl3);
        lbl3.setBounds(21, 125, 35, 15);

        lbl4.setText("Dirección:");
        getContentPane().add(lbl4);
        lbl4.setBounds(21, 165, 48, 15);

        lbl5.setText("Fecha:");
        getContentPane().add(lbl5);
        lbl5.setBounds(267, 125, 33, 15);

        lbl6.setText("Teléfono:");
        getContentPane().add(lbl6);
        lbl6.setBounds(267, 165, 45, 15);

        lbl7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl7.setText("Código");
        getContentPane().add(lbl7);
        lbl7.setBounds(21, 211, 33, 15);

        cbxCodigo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        cbxCodigo1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo1ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo1);
        cbxCodigo1.setBounds(12, 245, 31, 24);

        txtDescripcion1.setText("jTextField5");
        getContentPane().add(txtDescripcion1);
        txtDescripcion1.setBounds(105, 245, 55, 19);

        txtCantidad1.setText("jTextField6");
        txtCantidad1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidad1KeyReleased(evt);
            }
        });
        getContentPane().add(txtCantidad1);
        txtCantidad1.setBounds(181, 245, 55, 19);

        txtPrecio1.setText("jTextField7");
        getContentPane().add(txtPrecio1);
        txtPrecio1.setBounds(262, 245, 55, 19);

        txtSubtotal1.setText("jTextField8");
        getContentPane().add(txtSubtotal1);
        txtSubtotal1.setBounds(343, 245, 55, 19);

        lbl8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl8.setText("Descripción");
        getContentPane().add(lbl8);
        lbl8.setBounds(100, 210, 57, 15);

        lbl9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl9.setText("Cantidad");
        getContentPane().add(lbl9);
        lbl9.setBounds(189, 211, 42, 15);

        lbl10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl10.setText("Precio");
        getContentPane().add(lbl10);
        lbl10.setBounds(280, 210, 50, 15);

        lbl11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl11.setText("Subtotal");
        getContentPane().add(lbl11);
        lbl11.setBounds(351, 211, 39, 15);

        cbxCodigo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        cbxCodigo2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo2ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo2);
        cbxCodigo2.setBounds(12, 274, 31, 24);

        txtDescripcion2.setText("jTextField5");
        getContentPane().add(txtDescripcion2);
        txtDescripcion2.setBounds(105, 274, 55, 19);

        txtCantidad2.setText("jTextField6");
        txtCantidad2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidad2KeyReleased(evt);
            }
        });
        getContentPane().add(txtCantidad2);
        txtCantidad2.setBounds(181, 274, 55, 19);

        txtPrecio2.setText("jTextField7");
        getContentPane().add(txtPrecio2);
        txtPrecio2.setBounds(262, 274, 55, 19);

        txtSubtotal2.setText("jTextField8");
        getContentPane().add(txtSubtotal2);
        txtSubtotal2.setBounds(343, 274, 55, 19);

        cbxCodigo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        cbxCodigo3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo3ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo3);
        cbxCodigo3.setBounds(12, 303, 31, 24);

        txtDescripcion3.setText("jTextField5");
        getContentPane().add(txtDescripcion3);
        txtDescripcion3.setBounds(105, 303, 55, 19);

        txtCantidad3.setText("jTextField6");
        txtCantidad3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidad3KeyReleased(evt);
            }
        });
        getContentPane().add(txtCantidad3);
        txtCantidad3.setBounds(181, 303, 55, 19);

        txtPrecio3.setText("jTextField7");
        getContentPane().add(txtPrecio3);
        txtPrecio3.setBounds(262, 303, 55, 19);

        txtSubtotal3.setText("jTextField8");
        getContentPane().add(txtSubtotal3);
        txtSubtotal3.setBounds(343, 303, 55, 19);

        cbxCodigo4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        cbxCodigo4.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo4ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo4);
        cbxCodigo4.setBounds(12, 332, 31, 24);

        txtDescripcion4.setText("jTextField5");
        getContentPane().add(txtDescripcion4);
        txtDescripcion4.setBounds(105, 332, 55, 19);

        txtCantidad4.setText("jTextField6");
        txtCantidad4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidad4KeyReleased(evt);
            }
        });
        getContentPane().add(txtCantidad4);
        txtCantidad4.setBounds(181, 332, 55, 19);

        txtPrecio4.setText("jTextField7");
        getContentPane().add(txtPrecio4);
        txtPrecio4.setBounds(262, 332, 55, 19);

        txtSubtotal4.setText("jTextField8");
        getContentPane().add(txtSubtotal4);
        txtSubtotal4.setBounds(343, 332, 55, 19);

        lbl12.setText("Subtotal");
        getContentPane().add(lbl12);
        lbl12.setBounds(164, 402, 39, 15);

        lbl13.setText("Descuento");
        getContentPane().add(lbl13);
        lbl13.setBounds(164, 437, 52, 15);

        lbl14.setText("IVA");
        getContentPane().add(lbl14);
        lbl14.setBounds(164, 469, 18, 15);

        lbl15.setText("Total");
        getContentPane().add(lbl15);
        lbl15.setBounds(164, 498, 23, 15);

        txtSubtotal.setText("jTextField21");
        getContentPane().add(txtSubtotal);
        txtSubtotal.setBounds(336, 399, 61, 19);

        txtDescuento.setText("jTextField22");
        getContentPane().add(txtDescuento);
        txtDescuento.setBounds(336, 434, 61, 19);

        cbxCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        cbxCliente.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxClienteItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCliente);
        cbxCliente.setBounds(110, 122, 80, 24);

        txtIva.setText("jTextField1");
        getContentPane().add(txtIva);
        txtIva.setBounds(336, 469, 55, 19);

        txtTotal.setText("jTextField23");
        getContentPane().add(txtTotal);
        txtTotal.setBounds(336, 498, 61, 19);

        txtPorcentajeDsct.setText("jTextField3");
        txtPorcentajeDsct.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPorcentajeDsctKeyReleased(evt);
            }
        });
        getContentPane().add(txtPorcentajeDsct);
        txtPorcentajeDsct.setBounds(241, 434, 50, 19);

        txtPorcentajeIva.setText("jTextField24");
        txtPorcentajeIva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPorcentajeIvaKeyReleased(evt);
            }
        });
        getContentPane().add(txtPorcentajeIva);
        txtPorcentajeIva.setBounds(241, 469, 50, 19);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed
        // TODO add your handling code here:
        pj = Toolkit.getDefaultToolkit().getPrintJob(new Frame(), "Factura", null);
        this.imprimir((String)cbxCliente.getSelectedItem(), txtFecha.getText(),txtDireccion.getText(), txtTelefono.getText(), (String)cbxCodigo1.getSelectedItem(), (String)cbxCodigo2.getSelectedItem(), (String)cbxCodigo3.getSelectedItem(), (String)cbxCodigo4.getSelectedItem(), 
                txtDescripcion1.getText(), txtDescripcion2.getText(), txtDescripcion3.getText(), txtDescripcion4.getText(),
                txtCantidad1.getText(), txtCantidad2.getText(), txtCantidad3.getText(), txtCantidad4.getText(),
                txtPrecio1.getText(), txtPrecio2.getText(), txtPrecio3.getText(), txtPrecio4.getText(),
                txtSubtotal1.getText(), txtSubtotal2.getText(), txtSubtotal3.getText(), txtSubtotal4.getText(),
                txtSubtotal.getText(), txtDescuento.getText(), txtIva.getText(), txtTotal.getText() );

        
    }//GEN-LAST:event_btnImprimirActionPerformed

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        try {
            // TODO add your handling code here:
            
            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsCliente = factura.cargarClientes();
            
            while (rsCliente.next())
            {
                cbxCliente.addItem(rsCliente.getObject(1).toString());
            }
            ResultSet rsProductos = factura.cargarProductos();
            while (rsProductos.next())
            {
                cbxCodigo1.addItem(rsProductos.getObject(1).toString());
                cbxCodigo2.addItem(rsProductos.getObject(1).toString());
                cbxCodigo3.addItem(rsProductos.getObject(1).toString());
                cbxCodigo4.addItem(rsProductos.getObject(1).toString());
            }
            ////////
            ResultSet rsPedido = factura.numeroPedido();
            while(rsPedido.next())
            {
                lblfactu.setText(rsPedido.getObject(1).toString());
            }
            
            factura.cerrarFactura();
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formInternalFrameOpened

    private void cbxCodigo1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo1ItemStateChanged
        
        try {
            // TODO add your handling code here: con block trycatch
            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto1 = factura.consultarProducto(cbxCodigo1.getSelectedItem().toString());
            while (rsProducto1.next())
            {
                txtDescripcion1.setText(rsProducto1.getObject(1).toString());
                txtPrecio1.setText(rsProducto1.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (cbxCodigo1.getSelectedItem().equals(""))
        {
            txtPrecio1.setText("");
            txtDescripcion1.setText("");
        }
       
        
    }//GEN-LAST:event_cbxCodigo1ItemStateChanged

    private void cbxClienteItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxClienteItemStateChanged
        try {
            // TODO add your handling code here:
            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsCliente2 = factura.consultarClientes2(cbxCliente.getSelectedItem().toString());
            while (rsCliente2.next())
            {
                txtDireccion.setText(rsCliente2.getObject(1).toString());
                txtTelefono.setText(rsCliente2.getObject(2).toString());
                
                idCliente = rsCliente2.getObject(3).toString();
                System.out.println(idCliente);
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (cbxCliente.getSelectedItem().equals(""))
        {
            txtDireccion.setText("");
            txtTelefono.setText("");
        }
        
    }//GEN-LAST:event_cbxClienteItemStateChanged

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try {
            //con block trycatch
            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            factura.guardarPedido(idCliente, "1",txtFecha.getText());
            factura.guardarDetalle(lblfactu.getText(), cbxCodigo1.getSelectedItem().toString(), txtCantidad1.getText(), txtPrecio1.getText());
            factura.guardarDetalle(lblfactu.getText(), cbxCodigo2.getSelectedItem().toString(), txtCantidad2.getText(), txtPrecio2.getText());
            factura.guardarDetalle(lblfactu.getText(), cbxCodigo3.getSelectedItem().toString(), txtCantidad3.getText(), txtPrecio3.getText());
            factura.guardarDetalle(lblfactu.getText(), cbxCodigo4.getSelectedItem().toString(), txtCantidad4.getText(), txtPrecio4.getText());
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void cbxCodigo2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo2ItemStateChanged
        try {
            // TODO add your handling code here:
            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto2 = factura.consultarProducto(cbxCodigo2.getSelectedItem().toString());
            while (rsProducto2.next())
            {
                txtDescripcion2.setText(rsProducto2.getObject(1).toString());
                txtPrecio2.setText(rsProducto2.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (cbxCodigo2.getSelectedItem().equals(""))
        {
            txtPrecio2.setText("");
            txtDescripcion2.setText("");
        }
    }//GEN-LAST:event_cbxCodigo2ItemStateChanged

    private void cbxCodigo3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo3ItemStateChanged
        try {
            // TODO add your handling code here:

            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto3 = factura.consultarProducto3(cbxCodigo3.getSelectedItem().toString());
            while (rsProducto3.next())
            {
                txtDescripcion3.setText(rsProducto3.getObject(1).toString());
                txtPrecio3.setText(rsProducto3.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (cbxCodigo3.getSelectedItem().equals(""))
        {
            txtPrecio3.setText("");
            txtDescripcion3.setText("");
        }
    }//GEN-LAST:event_cbxCodigo3ItemStateChanged

    private void cbxCodigo4ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo4ItemStateChanged
        try {
            // TODO add your handling code here:
            Factura factura = new Factura("root","3342","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto4 = factura.consultarProducto4(cbxCodigo4.getSelectedItem().toString());
            while (rsProducto4.next())
            {
                txtDescripcion4.setText(rsProducto4.getObject(1).toString());
                txtPrecio4.setText(rsProducto4.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (cbxCodigo4.getSelectedItem().equals(""))
        {
            txtPrecio4.setText("");
            txtDescripcion4.setText("");
        }
    }//GEN-LAST:event_cbxCodigo4ItemStateChanged

    private void txtCantidad1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidad1KeyReleased
        // TODO add your handling code here:
        if (! txtCantidad1.getText().equals(""))
        {
            subto1= Integer.valueOf(txtCantidad1.getText()) * Double.valueOf(txtPrecio1.getText());
            txtSubtotal1.setText(String.valueOf(subto1));
            
            txtSubtotal.setText(String.valueOf(subto1));
            //respuesta1= Double.valueOf(txtPrecio1.getText());
            //System.out.println(respuesta1);
            
        }
        else 
        {
            txtSubtotal1.setText("");
            txtSubtotal.setText("");
        }
    }//GEN-LAST:event_txtCantidad1KeyReleased

    private void txtCantidad2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidad2KeyReleased
        // TODO add your handling code here:
        if (! txtCantidad2.getText().equals(""))
        {
            subto2= Integer.valueOf(txtCantidad2.getText()) * Double.valueOf(txtPrecio2.getText());
            txtSubtotal2.setText(String.valueOf(subto2));
            
            txtSubtotal.setText(String.valueOf(subto1+subto2));
        }
        else 
        {
            txtSubtotal2.setText("");
            txtSubtotal.setText(String.valueOf(subto1));
        }
    }//GEN-LAST:event_txtCantidad2KeyReleased

    private void txtCantidad3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidad3KeyReleased
        // TODO add your handling code here:
        if (! txtCantidad3.getText().equals(""))
        {
            subto3= Integer.valueOf(txtCantidad3.getText()) * Double.valueOf(txtPrecio3.getText());
            txtSubtotal3.setText(String.valueOf(subto3));
            
            txtSubtotal.setText(String.valueOf(subto1+subto2+subto3));
        }
        else 
        {
            txtSubtotal3.setText("");
            txtSubtotal.setText(String.valueOf(subto1+subto2));
        }
    }//GEN-LAST:event_txtCantidad3KeyReleased

    private void txtCantidad4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidad4KeyReleased
        // TODO add your handling code here:
        if (! txtCantidad4.getText().equals(""))
        {
            subto4= Integer.valueOf(txtCantidad4.getText()) * Double.valueOf(txtPrecio4.getText());
            txtSubtotal4.setText(String.valueOf(subto4));
            
            
            txtSubtotal.setText(String.valueOf(subto1+subto2+subto3+subto4));
        }
        else 
        {
            txtSubtotal4.setText("");
            txtSubtotal.setText(String.valueOf(subto1+subto2+subto3));
        }
    }//GEN-LAST:event_txtCantidad4KeyReleased

    private void txtPorcentajeDsctKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPorcentajeDsctKeyReleased
        // TODO add your handling code here:
        if (! txtPorcentajeDsct.getText().equals(""))
        {
            descto= Double.valueOf(txtSubtotal.getText()) - ((Double.valueOf(txtSubtotal.getText()) * Integer.valueOf(txtPorcentajeDsct.getText()))/100);
            txtDescuento.setText(String.valueOf(descto));
            
        }
        else 
        {
            //txtPorcentajeDsct.setText("");
            txtDescuento.setText("");
        }
    }//GEN-LAST:event_txtPorcentajeDsctKeyReleased

    private void txtPorcentajeIvaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPorcentajeIvaKeyReleased
        // TODO add your handling code here:
        if (! txtDescuento.getText().equals(""))
        {
            iva= ((Double.valueOf(txtDescuento.getText()) * Integer.valueOf(txtPorcentajeIva.getText()))/100);
            iva = Math.round(iva*100);
            iva=iva/100;
            txtIva.setText(String.valueOf(iva));
            txtTotal.setText(String.valueOf(iva + Double.valueOf(txtDescuento.getText()) ));
            
        }
        else 
        {
            iva= ((Double.valueOf(txtSubtotal.getText()) * Integer.valueOf(txtPorcentajeIva.getText()))/100);
            iva = Math.round(iva*100);
            iva=iva/100;
            txtIva.setText(String.valueOf(iva));
            txtTotal.setText(String.valueOf(iva + Double.valueOf(txtSubtotal.getText()) ));
        }
        
        
    }//GEN-LAST:event_txtPorcentajeIvaKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cbxCliente;
    private javax.swing.JComboBox<String> cbxCodigo1;
    private javax.swing.JComboBox<String> cbxCodigo2;
    private javax.swing.JComboBox<String> cbxCodigo3;
    private javax.swing.JComboBox<String> cbxCodigo4;
    private javax.swing.JLabel lbl1;
    private javax.swing.JLabel lbl10;
    private javax.swing.JLabel lbl11;
    private javax.swing.JLabel lbl12;
    private javax.swing.JLabel lbl13;
    private javax.swing.JLabel lbl14;
    private javax.swing.JLabel lbl15;
    private javax.swing.JLabel lbl3;
    private javax.swing.JLabel lbl4;
    private javax.swing.JLabel lbl5;
    private javax.swing.JLabel lbl6;
    private javax.swing.JLabel lbl7;
    private javax.swing.JLabel lbl8;
    private javax.swing.JLabel lbl9;
    private javax.swing.JLabel lblfactu;
    private javax.swing.JTextField txtCantidad1;
    private javax.swing.JTextField txtCantidad2;
    private javax.swing.JTextField txtCantidad3;
    private javax.swing.JTextField txtCantidad4;
    private javax.swing.JTextField txtDescripcion1;
    private javax.swing.JTextField txtDescripcion2;
    private javax.swing.JTextField txtDescripcion3;
    private javax.swing.JTextField txtDescripcion4;
    private javax.swing.JTextField txtDescuento;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIva;
    private javax.swing.JTextField txtPorcentajeDsct;
    private javax.swing.JTextField txtPorcentajeIva;
    private javax.swing.JTextField txtPrecio1;
    private javax.swing.JTextField txtPrecio2;
    private javax.swing.JTextField txtPrecio3;
    private javax.swing.JTextField txtPrecio4;
    private javax.swing.JTextField txtSubtotal;
    private javax.swing.JTextField txtSubtotal1;
    private javax.swing.JTextField txtSubtotal2;
    private javax.swing.JTextField txtSubtotal3;
    private javax.swing.JTextField txtSubtotal4;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
